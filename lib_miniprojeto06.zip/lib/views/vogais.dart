import 'package:flutter/material.dart';

class Vogais extends StatefulWidget {
  const Vogais({ Key? key }) : super(key: key);

  @override
  _VogaisState createState() => _VogaisState();
}

class _VogaisState extends State<Vogais> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text("Vogais"),
    );
  }
}